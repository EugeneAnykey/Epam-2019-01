﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FileSystemDemo
{
	class Program
	{
		static void Main(string[] args)
		{
			EvironmentDemo.EnvironmentDemo();
		}
	}
}
