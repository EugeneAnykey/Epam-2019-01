﻿using System;
using System.Collections.Generic;

namespace DemoApplication
{
	public static class ErrorListDemo
	{
		public static void Demo()
		{
			var errorList = new ErrorList();
			errorList.AddError("Error 1");
			errorList.AddError("Error 2");
			errorList.AddError("Error 3");

			foreach (var error in errorList.Errors)
			{
				Console.WriteLine(error);
			}
		}
	}

	// Пример неправильного применения IDisposable.
	public class ErrorList : IDisposable
	{
		public List<string> Errors { get; private set; }

		public ErrorList()
		{
			Errors = new List<string>();
		}

		public virtual void AddError(string error)
		{
			Errors.Add(error);
		}

		// Совершенно необязательно...
		public void Dispose()
		{
			if (Errors != null)
			{
				Errors.Clear();
				Errors = null;
			}
		}
	}
}
