﻿using System;
using System.IO;

namespace DemoApplication
{
	public static class FileErrorListDemo
	{
		public static void Demo()
		{
			// сначала без using
			// конструкция using вызовет dispose даже в случае исключения
			using (var fileErrorList = new FileErrorList(@"D:\errorsDemo.txt"))
			{
				fileErrorList.AddError("Error 1");
				fileErrorList.AddError("Error 2");
				fileErrorList.AddError("Error 3");
				fileErrorList.AddError("Error 4");
				fileErrorList.AddError("Error 5");
				//throw new Exception();
				fileErrorList.AddError("Error 6");
				fileErrorList.AddError("Error 7");
			} // вызывает dispose
		}
	}

	// Пример правильного применения IDisposable.
	public class FileErrorList : ErrorList, IDisposable
	{
		private readonly StreamWriter _fileStream;

		public FileErrorList(string fileName)
		{
			_fileStream = File.CreateText(fileName);
		}

		public override void AddError(string error)
		{
			_fileStream.WriteLine(error);
			Console.WriteLine(error);
		}

		public new void Dispose()
		{
			if (_fileStream != null)
			{
				_fileStream.Dispose();
			}
		}
	}
}
