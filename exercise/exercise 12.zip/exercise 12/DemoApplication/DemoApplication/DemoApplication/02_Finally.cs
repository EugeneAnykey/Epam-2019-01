﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DemoApplication
{
	public class Finally
	{
		public static List<int> ReasData(string name)
		{
			StreamReader fs = File.OpenText(name);
			List<int> res = new List<int>();

			try
			{
				for (int i = 0; i < 10; i++)
				{
					string line = fs.ReadLine();
					res.Add(int.Parse(line));
				}

				return res;
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				return new List<int>();
			}
			finally
			{
				// будет выполнено всегда
				fs.Close();
			}
		}
	}
}
