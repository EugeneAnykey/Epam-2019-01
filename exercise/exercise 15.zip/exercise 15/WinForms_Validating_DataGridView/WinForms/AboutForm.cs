﻿using System.Windows.Forms;

namespace WinForms
{
	public partial class AboutForm : Form
	{
		public AboutForm()
		{
			InitializeComponent();

		}
	}
}
