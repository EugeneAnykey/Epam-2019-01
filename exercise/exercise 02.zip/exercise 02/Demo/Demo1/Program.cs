﻿using System;

namespace Demo1
{
	class Program
	{
		static void Main(string[] args)
		{
			int num = (int)(5 / 1.4);
			Console.WriteLine($"Result {num}");

			bool isSuccess = true;
			int num1 = 0;
			if (isSuccess)
			{
				num1 = 10;
			}
			else
			{
				num1 = 9;
			}

			num1 = isSuccess ? 10 : 9;

			var str = "string";
			var name = str?.ToLowerInvariant() ?? "default";

			try
			{
				int i = int.Parse("5");
				Console.WriteLine($"You have entered {i}");
				return;
			}
			catch (Exception e)
			{
				Console.WriteLine("I am in catch");
				return;
			}
			finally
			{
				Console.WriteLine("I am in finally");
			}
		}
	}
}
