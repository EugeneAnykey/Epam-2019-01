﻿using System;

namespace BasicElements
{
	public class ValueTypes
	{
		public static void DemoMain(string[] args)
		{
			int x = 5;
			Console.WriteLine(x);

			byte b = 255;
			int i = int.MaxValue;
			uint ui = uint.MinValue;

			double d = 5.6412;
			decimal dl = 6.9999999999M;

			bool f = true;
			char c = 'a';

			SPoint ps = new SPoint();
			Console.WriteLine(ps);

			ps.X = 5;
			ps.Y = 6;
			Console.WriteLine("x:{0} - y:{1}", ps.X, ps.Y);

			DayOfWeek day = DayOfWeek.Saturday;
			Console.WriteLine(day);
			Console.WriteLine((int)day);

			// явное приведение типов
			sbyte sb = -5;
			Console.WriteLine("Type:{0} Value:{1}", sb.GetType().Name, sb);
			double dd = (double)sb; // double dd = sb; неявное
			Console.WriteLine("Type:{0} Value:{1}", dd.GetType().Name, dd);

			// ошибка приведения типов
			dd = 54444444.669;
			sb = (sbyte)dd;
			Console.WriteLine("Type:{0} Value:{1}", sb.GetType().Name, sb);

			// неявное приведение типов
			int k = 2;
			int l = 4;
			Console.WriteLine(k / l);
			Console.WriteLine((double)k / l);
		}
	}

	enum DayOfWeek
	{
		Monday = 1,
		Tuesday = 2,
		Wednesday = 3,
		Thursday = 4,
		Friday = 5,
		Saturday = 6,
		Sunday = 7
	}

	struct SPoint
	{
		public int X;
		public int Y;
	}
}
