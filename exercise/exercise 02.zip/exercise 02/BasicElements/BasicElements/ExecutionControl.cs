﻿using System;

namespace BasicElements
{
	public class ExecutionControl
	{
		public static void DemoMain(string[] args)
		{
			string str = Console.ReadLine();
			int n;

			switch (str)
			{
				case "Понедельник":
					n = 5;
					break;
				case "Вторник":
					n = 4;
					break;
				case "Среда":
					n = 3;
					break;
				case "Четверг":
					n = 2;
					break;
				case "Пятница":
					n = 1;
					break;
				default:
					n = 0;
					break;
			}

			Console.WriteLine("Осталось работать {0} дней", n);

			int x = 10;
			int y = 100;

			int max;
			if (x > y)
				max = x;
			else
				max = y;

			Console.WriteLine(max);

			// идентично
			max = x > y ? x : y;
			Console.WriteLine(max);

			// циклы выводим чсила от 0 до N
			Console.Write("N = ");
			str = Console.ReadLine();
			int length = int.Parse(str);

			for (int i = 0; i < length; i++)
			{
				Console.Write(" {0}", i);
				//continue;
				//break;
			}

			int j = 0;
			while (j < length)
			{
				Console.Write(" {0}", j++);
			}

			// обработка ошибок
			str = Console.ReadLine();
			try
			{
				int input = int.Parse(str);
			}
			catch (FormatException /*f*/)
			{
				Console.WriteLine("Incorrect input");
			}
		}
	}
}
