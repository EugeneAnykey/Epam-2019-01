﻿namespace BasicElements
{
	class Program
	{
		static void Main(string[] args)
		{
			ValueTypes.DemoMain(args);
			//ExecutionControl.DemoMain(args);
		}
	}
}
