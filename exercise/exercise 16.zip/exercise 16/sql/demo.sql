﻿USE master
IF(db_id(N'UsersAndAwards')) IS NOT NULL
	DROP DATABASE UsersAndAwards

CREATE DATABASE UsersAndAwards
GO

USE UsersAndAwards
CREATE TABLE Users(
	[Id] int not null primary key identity(1,1),
	[Name] nvarchar(150),
	[Birthdate] datetime2
	)

INSERT INTO Users
VALUES(N'User 1', '2010-10-02')
INSERT INTO Users
VALUES(N'User 3', '2010-10-02')
INSERT INTO Users
VALUES(N'User 4', '2010-10-02')

USE UsersAndAwards
CREATE TABLE Awards(
	[Id] int not null primary key identity(1,1),
	[Name] nvarchar(150),
	[Description] nvarchar(150)
	)

INSERT INTO Awards
VALUES(N'nobel prize', N'epic award')
INSERT INTO Awards
VALUES(N'another prize', 'common award')

CREATE TABLE Relations(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[UserId] INT NOT NULL,
	[AwardId] INT NOT NULL,
	FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
	FOREIGN KEY (AwardId) REFERENCES Awards(Id) ON DELETE CASCADE,
	)

INSERT INTO Relations
VALUES(1, 1), (1,2),(2,2)

CREATE PROCEDURE AddAward(
	@name nvarchar(150),
	@description nvarchar(150))
AS
BEGIN
	INSERT INTO Awards
	VALUES(@name, @description)
END

CREATE TYPE AwardsIds
AS TABLE(id int)

ALTER PROCEDURE AddUser(
	@name nvarchar(150),
	@bdate datetime2,
	@awardIds AwardsIds readonly)
AS
BEGIN
	DECLARE @userId AS TABLE(id int)

	INSERT INTO Users
	OUTPUT Inserted.Id INTO @userId
	VALUES(@name, @bdate)

	INSERT INTO Relations
	SELECT [@userId].id, [@awardIds].id FROM @awardIds, @userId
END

BEGIN
DECLARE @awards AwardsIds;
INSERT INTO @awards VALUES(1),(2)
EXEC AddUser N'user 123', N'2000-01-01', @awards
END

SELECT * FROM dbo.Users

DELETE FROM dbo.Users
WHERE id IN (SELECT TOP(2) id FROM dbo.Users)

UPDATE dbo.Users
SET Name = 'asdqqwe45'
WHERE Id = 3

