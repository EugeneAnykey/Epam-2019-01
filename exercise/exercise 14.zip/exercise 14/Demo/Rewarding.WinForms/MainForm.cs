﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rewarding.WinForms
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Click(object sender, EventArgs e)
		{

		}

		private void MainForm_ResizeBegin(object sender, EventArgs e)
		{

		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnAddUser_Click(object sender, EventArgs e)
		{
			AddUser();
		}

		private void btnContextMenuAdd_Click(object sender, EventArgs e)
		{
			AddUser();
		}

		private void AddUser()
		{

		}
	}
}
