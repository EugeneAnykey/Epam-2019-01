﻿namespace Rewarding.WinForms
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.ctlMainMenu = new System.Windows.Forms.MenuStrip();
			this.ctlFileMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.btnExit = new System.Windows.Forms.ToolStripMenuItem();
			this.ctlEditMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.btnAddUser = new System.Windows.Forms.ToolStripMenuItem();
			this.ctlTabPanel = new System.Windows.Forms.TabControl();
			this.ctlUsersPage = new System.Windows.Forms.TabPage();
			this.ctlUsersCOntextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ctlUsers = new System.Windows.Forms.DataGridView();
			this.ctlRewardsPage = new System.Windows.Forms.TabPage();
			this.ctlRewardsContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ctlRewards = new System.Windows.Forms.DataGridView();
			this.btnAddUserContextMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.btnEditContextMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.btnAddRewardContextMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.btnEditRewardContextMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.ctlMainMenu.SuspendLayout();
			this.ctlTabPanel.SuspendLayout();
			this.ctlUsersPage.SuspendLayout();
			this.ctlUsersCOntextMenu.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.ctlUsers)).BeginInit();
			this.ctlRewardsPage.SuspendLayout();
			this.ctlRewardsContextMenu.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.ctlRewards)).BeginInit();
			this.SuspendLayout();
			// 
			// ctlMainMenu
			// 
			this.ctlMainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlFileMenu,
            this.ctlEditMenu});
			this.ctlMainMenu.Location = new System.Drawing.Point(0, 0);
			this.ctlMainMenu.Name = "ctlMainMenu";
			this.ctlMainMenu.Size = new System.Drawing.Size(865, 24);
			this.ctlMainMenu.TabIndex = 0;
			this.ctlMainMenu.Text = "menuStrip1";
			// 
			// ctlFileMenu
			// 
			this.ctlFileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnExit});
			this.ctlFileMenu.Name = "ctlFileMenu";
			this.ctlFileMenu.Size = new System.Drawing.Size(37, 20);
			this.ctlFileMenu.Text = "&File";
			// 
			// btnExit
			// 
			this.btnExit.Name = "btnExit";
			this.btnExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
			this.btnExit.Size = new System.Drawing.Size(134, 22);
			this.btnExit.Text = "Exit";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// ctlEditMenu
			// 
			this.ctlEditMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAddUser});
			this.ctlEditMenu.Name = "ctlEditMenu";
			this.ctlEditMenu.Size = new System.Drawing.Size(39, 20);
			this.ctlEditMenu.Text = "Edit";
			// 
			// btnAddUser
			// 
			this.btnAddUser.Name = "btnAddUser";
			this.btnAddUser.Size = new System.Drawing.Size(131, 22);
			this.btnAddUser.Text = "Add User...";
			this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
			// 
			// ctlTabPanel
			// 
			this.ctlTabPanel.Controls.Add(this.ctlUsersPage);
			this.ctlTabPanel.Controls.Add(this.ctlRewardsPage);
			this.ctlTabPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ctlTabPanel.Location = new System.Drawing.Point(0, 24);
			this.ctlTabPanel.Name = "ctlTabPanel";
			this.ctlTabPanel.SelectedIndex = 0;
			this.ctlTabPanel.Size = new System.Drawing.Size(865, 380);
			this.ctlTabPanel.TabIndex = 2;
			// 
			// ctlUsersPage
			// 
			this.ctlUsersPage.ContextMenuStrip = this.ctlUsersCOntextMenu;
			this.ctlUsersPage.Controls.Add(this.ctlUsers);
			this.ctlUsersPage.Location = new System.Drawing.Point(4, 22);
			this.ctlUsersPage.Name = "ctlUsersPage";
			this.ctlUsersPage.Padding = new System.Windows.Forms.Padding(3);
			this.ctlUsersPage.Size = new System.Drawing.Size(857, 354);
			this.ctlUsersPage.TabIndex = 0;
			this.ctlUsersPage.Text = "Users";
			this.ctlUsersPage.UseVisualStyleBackColor = true;
			// 
			// ctlUsersCOntextMenu
			// 
			this.ctlUsersCOntextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAddUserContextMenu,
            this.btnEditContextMenu});
			this.ctlUsersCOntextMenu.Name = "ctlUsersCOntextMenu";
			this.ctlUsersCOntextMenu.Size = new System.Drawing.Size(106, 48);
			// 
			// ctlUsers
			// 
			this.ctlUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.ctlUsers.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ctlUsers.Location = new System.Drawing.Point(3, 3);
			this.ctlUsers.Name = "ctlUsers";
			this.ctlUsers.Size = new System.Drawing.Size(851, 348);
			this.ctlUsers.TabIndex = 0;
			// 
			// ctlRewardsPage
			// 
			this.ctlRewardsPage.ContextMenuStrip = this.ctlRewardsContextMenu;
			this.ctlRewardsPage.Controls.Add(this.ctlRewards);
			this.ctlRewardsPage.Location = new System.Drawing.Point(4, 22);
			this.ctlRewardsPage.Name = "ctlRewardsPage";
			this.ctlRewardsPage.Padding = new System.Windows.Forms.Padding(3);
			this.ctlRewardsPage.Size = new System.Drawing.Size(857, 354);
			this.ctlRewardsPage.TabIndex = 1;
			this.ctlRewardsPage.Text = "Rewards";
			this.ctlRewardsPage.UseVisualStyleBackColor = true;
			// 
			// ctlRewardsContextMenu
			// 
			this.ctlRewardsContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAddRewardContextMenu,
            this.btnEditRewardContextMenu});
			this.ctlRewardsContextMenu.Name = "ctlRewardsContextMenu";
			this.ctlRewardsContextMenu.Size = new System.Drawing.Size(153, 70);
			// 
			// ctlRewards
			// 
			this.ctlRewards.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.ctlRewards.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ctlRewards.Location = new System.Drawing.Point(3, 3);
			this.ctlRewards.Name = "ctlRewards";
			this.ctlRewards.Size = new System.Drawing.Size(851, 348);
			this.ctlRewards.TabIndex = 0;
			// 
			// btnAddUserContextMenu
			// 
			this.btnAddUserContextMenu.Name = "btnAddUserContextMenu";
			this.btnAddUserContextMenu.Size = new System.Drawing.Size(152, 22);
			this.btnAddUserContextMenu.Text = "Add...";
			this.btnAddUserContextMenu.Click += new System.EventHandler(this.btnAddUserContextMenu_Click);
			// 
			// btnEditContextMenu
			// 
			this.btnEditContextMenu.Name = "btnEditContextMenu";
			this.btnEditContextMenu.Size = new System.Drawing.Size(152, 22);
			this.btnEditContextMenu.Text = "Edit...";
			this.btnEditContextMenu.Click += new System.EventHandler(this.btnEditContextMenu_Click);
			// 
			// btnAddRewardContextMenu
			// 
			this.btnAddRewardContextMenu.Name = "btnAddRewardContextMenu";
			this.btnAddRewardContextMenu.Size = new System.Drawing.Size(152, 22);
			this.btnAddRewardContextMenu.Text = "Add...";
			this.btnAddRewardContextMenu.Click += new System.EventHandler(this.btnAddRewardContextMenu_Click);
			// 
			// btnEditRewardContextMenu
			// 
			this.btnEditRewardContextMenu.Name = "btnEditRewardContextMenu";
			this.btnEditRewardContextMenu.Size = new System.Drawing.Size(152, 22);
			this.btnEditRewardContextMenu.Text = "Edit...";
			this.btnEditRewardContextMenu.Click += new System.EventHandler(this.btnEditRewardContextMenu_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(865, 404);
			this.Controls.Add(this.ctlTabPanel);
			this.Controls.Add(this.ctlMainMenu);
			this.MainMenuStrip = this.ctlMainMenu;
			this.Name = "MainForm";
			this.Text = "Users and Rewards";
			this.ResizeBegin += new System.EventHandler(this.MainForm_ResizeBegin);
			this.Click += new System.EventHandler(this.MainForm_Click);
			this.ctlMainMenu.ResumeLayout(false);
			this.ctlMainMenu.PerformLayout();
			this.ctlTabPanel.ResumeLayout(false);
			this.ctlUsersPage.ResumeLayout(false);
			this.ctlUsersCOntextMenu.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.ctlUsers)).EndInit();
			this.ctlRewardsPage.ResumeLayout(false);
			this.ctlRewardsContextMenu.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.ctlRewards)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip ctlMainMenu;
		private System.Windows.Forms.ToolStripMenuItem ctlFileMenu;
		private System.Windows.Forms.ToolStripMenuItem btnExit;
		private System.Windows.Forms.ToolStripMenuItem ctlEditMenu;
		private System.Windows.Forms.ToolStripMenuItem btnAddUser;
		private System.Windows.Forms.TabControl ctlTabPanel;
		private System.Windows.Forms.TabPage ctlUsersPage;
		private System.Windows.Forms.TabPage ctlRewardsPage;
		private System.Windows.Forms.ContextMenuStrip ctlUsersCOntextMenu;
		private System.Windows.Forms.DataGridView ctlUsers;
		private System.Windows.Forms.ContextMenuStrip ctlRewardsContextMenu;
		private System.Windows.Forms.DataGridView ctlRewards;
		private System.Windows.Forms.ToolStripMenuItem btnAddUserContextMenu;
		private System.Windows.Forms.ToolStripMenuItem btnEditContextMenu;
		private System.Windows.Forms.ToolStripMenuItem btnAddRewardContextMenu;
		private System.Windows.Forms.ToolStripMenuItem btnEditRewardContextMenu;
	}
}

