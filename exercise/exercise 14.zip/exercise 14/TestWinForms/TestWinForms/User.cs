﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWinForms
{
    public class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public User(string lastName, string firstName)
        {
            Id = 0;
            FirstName = firstName;
            LastName = lastName;
        }
    }
}
