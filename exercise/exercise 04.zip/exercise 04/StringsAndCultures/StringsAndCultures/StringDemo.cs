﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace StringsAndCultures
{
	public class StringDemo
	{
		public static void Demo(string[] args)
		{
			// объявление с инициализацией значением Сайт 
			string word = "Сайт";

			// строка в куче из пяти повторяющихся символов 
			string sssss = new string('s', 5);

			// string s2 = new string("s1"); так нельзя
			// string s2 = new string(); так тоже нельзя
			// а так можно:
			string s2; // это и есть объявление пустой строки в куче

			// преобразование в символьный массив явно заданной строки 
			char[] yes = "Привет посетителям Портала!".ToCharArray();

			// объявление строки с инициализацией символами из массива
			string greetings = new string(yes);

			Console.WriteLine(greetings.Contains("портал"));

			string substring = greetings.Substring(0, 7);
			
			Console.WriteLine(substring + ", Пользователь");
			Console.WriteLine(substring.Trim() +", Пользователь");

			int firstSymbolPosition = greetings.IndexOf("портал", StringComparison.OrdinalIgnoreCase);
			string withoutPortal = greetings.Remove(firstSymbolPosition, greetings.Length-1);

			Console.WriteLine(withoutPortal);

			//string ssss = "Привет посетителям Портала!" - "Портала";

			string s = "Универсальный магазин;Глобус;;;54.6191392;39.7980809;-777;;0;0.000;0;360.000;0;";
			string[] parts = s.Split(';');

			for (int i = 0; i < parts.Length; i++)
			{
				Console.WriteLine(parts[i]);
			}

			string s3 = String.Format("X:{0}, Y:{1}", 1.23, 4.56);



			Console.WriteLine("X:{0}, Y:{1}", 1.23, 4.56);
			Console.WriteLine("X:{0}, Y:{1}", 1.ToString(), 4.ToString());
			Console.WriteLine("X:{0}, Y:{1}", 1, 4);
		}
	}
}
