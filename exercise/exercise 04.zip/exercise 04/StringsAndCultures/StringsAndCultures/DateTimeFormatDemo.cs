﻿using System;
using System.Globalization;

namespace StringsAndCultures
{
	public class DateTimeFormatDemo
	{
		public static void Demo(string[] args)
		{
			DateTime date1 = new DateTime(2008, 4, 10);

			Console.WriteLine(date1.ToString("d", DateTimeFormatInfo.InvariantInfo));
			// Displays 04/10/2008
			Console.WriteLine(date1.ToString("d", CultureInfo.CreateSpecificCulture("en-US")));
			// Displays 4/10/2008
			Console.WriteLine(date1.ToString("d", CultureInfo.CreateSpecificCulture("en-NZ")));
			// Displays 10/04/2008
			Console.WriteLine(date1.ToString("d", CultureInfo.CreateSpecificCulture("ru-RU")));
			// Displays 10.04.2008
		}
	}
}
