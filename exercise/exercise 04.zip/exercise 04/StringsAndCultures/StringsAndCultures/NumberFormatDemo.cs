﻿using System;
using System.Globalization;

namespace StringsAndCultures
{
	public class NumberFormatDemo
	{
		public static void Demo(string[] args)
		{
			double value = 12345.6789;

			Console.WriteLine(value);

			Console.WriteLine(value.ToString("C", CultureInfo.CurrentCulture));

			Console.WriteLine(value.ToString("C3", CultureInfo.CurrentCulture));

			Console.WriteLine(value.ToString("C3", CultureInfo.CreateSpecificCulture("da-DK")));

			// The example displays the following output on a system whose
			// current culture is English (United States):
			//       $12,345.68
			//       $12,345.679
			//       kr 12.345,679

			Console.WriteLine(value.ToString("e4", CultureInfo.InvariantCulture));
			// Displays 1.2346e+004

			// CultureInfo также влияет на метод parse
			var stringValue = value.ToString("F", CultureInfo.CreateSpecificCulture("en-US"));

			Console.WriteLine(stringValue);

			// exception
			var parsedValue = double.Parse(stringValue, CultureInfo.CreateSpecificCulture("en-US"));
		}
	}
}
