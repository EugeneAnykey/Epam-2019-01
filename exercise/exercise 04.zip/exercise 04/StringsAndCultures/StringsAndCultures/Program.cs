﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime;
using System.Text;

namespace StringsAndCultures
{
	class Program
	{
		static void Main(string[] args)
		{
			//StringDemo.Demo(null);
			//DateTime date1 = new DateTime(2008, 4, 10);

			//Console.WriteLine(date1.ToString("d", DateTimeFormatInfo.InvariantInfo));
			//// Displays 04/10/2008
			//Console.WriteLine(date1.ToString("d", CultureInfo.CreateSpecificCulture("en-US")));
			//// Displays 4/10/2008
			//Console.WriteLine(date1.ToString("d", CultureInfo.CreateSpecificCulture("en-NZ")));
			//// Displays 10/04/2008
			//Console.WriteLine(date1.ToString("d", CultureInfo.CreateSpecificCulture("ru-RU")));
			//// Displays 10.04.2008

			//StringsImmutabilityDemo();

			//Console.WriteLine("Hello\tWorld");
			//Console.WriteLine("Hello\nWorld");

			//NumberFormatDemo.Demo(null);

			RegexDemo.Demo();
			Console.WriteLine("end.");
			Console.ReadKey();
		}

		static void StringsImmutabilityDemo()
		{
			GCSettings.LatencyMode = GCLatencyMode.LowLatency;

			StringBuilder str = new StringBuilder("");

			for (var i = 0; i < 50000; i++)
			{
				str.Append( " Some string ");
			}

			string[] arr = {"Hello", "World", "!"};

			Console.WriteLine(String.Join(" ----------- ", arr));

			string v = str.ToString();
		}
	}
}
