﻿using System;
using System.Text;

namespace StringsAndCultures
{
	public class StringBuilderDemo
	{
		public static void Demo(string[] args)
		{
			string[] arr = { "Andromeda", "Aquarius", "Corvus", "Columba", "Serpens", "Cassiopeia", "Pegasus"};

			// задача вывести одной строкой

			// неверно
			string result1 = "";
			for (var i = 0; i < arr.Length; i++)
			{
				result1 += arr[i];
			}
			Console.WriteLine(result1);

			// универсальный способ
			StringBuilder builder = new StringBuilder(arr[0]);
			for (var i = 0; i < arr.Length; i++)
			{
				builder.Append(arr[i]);
			}
			Console.WriteLine(builder.ToString());

			// задача вывести одной строкой через зяпятую
			// если все элементы известны сразу
			Console.WriteLine(string.Join(", ", arr));
		}
	}
}
