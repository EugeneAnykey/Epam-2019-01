﻿namespace StringsAndCultures
{
	public class CharDemo
	{
		public static void Demo(string[] args)
		{
			bool b1 = char.IsDigit('1'); // true
			char c1 = char.ToUpper('t'); // 'T'
			bool b2 = char.IsPunctuation("Это строка", 3); // false

			string str = "some string";
			char c = str[5];
		}
	}
}
