﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndEvents1
{
	class EventsGameTemplate
	{
		public static void Demo()
		{
			var mosters = new Monster[3];

			mosters[0] = new MoleRat();
			mosters[1] = new MoleRat();
			mosters[2] = new DeathClaw();

			var gameField = new GameField();

			foreach (var monster in mosters)
			{
				gameField.Move += monster.Move;
			}

			gameField.NextMove(); // задача что бы монстры
			// выполнили действия при наступлении хода
			gameField.NextMove();

		} 
	}

	class GameField
	{
		public event EventHandler Move;

		public void NextMove()
		{
			if (Move != null)
				Move(this, EventArgs.Empty);	
		}
	}

	abstract class Monster
	{
		public abstract void Move(object sender, EventArgs e);
	}

	class DeathClaw : Monster
	{
		public override void Move(object sender, EventArgs e)
		{
			Console.WriteLine("Death claw attacks!");
		}
	}

	class MoleRat : Monster
	{
		public override void Move(object sender, EventArgs e)
		{
			GameField fiel = (GameField) sender;
			Console.WriteLine("MoleRat runs away!");
		}
	}
}
