﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace DelegatesAndEvents
{
	public class EventsDemo
	{
		public static void Demo(string[] args)
		{
			Person mary = new Person { Name = "Mary" };
			Person kate = new Person { Name = "Kate" };


			Person hugo = new Person { Name = "Hugo" };
			Person john = new Person { Name = "John" };

			// подписываемся на события прихода людей
			hugo.Came += mary.Greet;
			hugo.Came += kate.Greet;

			john.Came += mary.Greet;
			john.Came += kate.Greet;

			Thread.Sleep(6000);

			// когда нибудь люди придут с события будут обработаны
			// это возможно даже в другом потоке UI
			//mary.OnCame();
			//hugo.OnCame();
		}

		
	}
}
