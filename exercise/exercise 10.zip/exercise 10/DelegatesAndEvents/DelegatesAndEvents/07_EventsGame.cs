﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndEvents
{
	public class EventsGame
	{
		public static void Demo()
		{
			var mosters = new Monster[3];

			mosters[0] = new MoleRat();
			mosters[1] = new MoleRat();
			mosters[2] = new DeathClaw();

			var gameField = new GameField();

			foreach (var monster in mosters)
			{
				gameField.NextMove += monster.MakeMove;
			}

			gameField.OnNextMove();
		}
	}

	class GameField
	{
		public EventHandler NextMove;

		public void OnNextMove()
		{
			if (NextMove != null)
			{
				NextMove(this, EventArgs.Empty);
			}
		}
	}

	abstract class Monster
	{
		public abstract void MakeMove(object sender, EventArgs e);
	}

	class DeathClaw : Monster
	{
		public override void MakeMove(object sender, EventArgs e)
		{
			var field = (GameField)sender; // информация о поле

			Console.WriteLine("DeathClaw attacks!");
		}
	}

	class MoleRat : Monster
	{
		public override void MakeMove(object sender, EventArgs e)
		{
			var field = (GameField)sender; // информация о поле

			Console.WriteLine("Mole rat is running away!");
		}
	}
}
