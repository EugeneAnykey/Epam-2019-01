﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace DelegatesAndEvents
{
	public class Threading
	{
        private static object syncLock = new object();
		public static void DemoMain()
		{
			Console.WriteLine("Main start");

			Action callback1 = () => Finish("Thread 1 finished");
			Action callback2 = () => Finish("Thread 2 finished");

			Thread th1 = new Thread(() => Run(300, 5, callback1));
			Thread th2 = new Thread(() => Run(100, 3, callback2));

			th1.Start();
			th2.Start();

			Console.WriteLine("Main exit");
		}

		static void Finish(string message)
		{
			Console.WriteLine(message);
		}

		static void Run(int sleepTime, int count, Action callback)
		{
            lock (syncLock)
            {
                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine(i);
                    Thread.Sleep(sleepTime);
                }
            }

			callback();
		}
	}
}
