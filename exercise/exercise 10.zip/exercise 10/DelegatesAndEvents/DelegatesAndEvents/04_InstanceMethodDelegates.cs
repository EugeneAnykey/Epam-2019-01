﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndEvents
{
	public class InstanceMethodDelegates
	{
		delegate void Message(string name);

		public static void Demo()
		{
			// Делегаты и экземплярные методы
			Person john = new Person { Name = "John" };

			Message greetByJohn = new Message(john.Greet);
			greetByJohn("Bill");
		}
	}
}
