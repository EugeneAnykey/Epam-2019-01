﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DelegatesAndEvents1;

namespace DelegatesAndEvents
{
	class Program
	{
		static void Main(string[] args)
		{
			//Delegates.Demo(null);
			//AnonimusMethods.Demo(null);
			//MulticastDelegates.Demo(null);
			//EventsDemo.Demo(null);
			//EventsGameTemplate.Demo();

			Threading.DemoMain();
            Console.ReadKey();
		}
	}
}
