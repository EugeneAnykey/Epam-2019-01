﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DelegatesAndEvents
{
	public delegate void Message(string name);

	public class Person
	{
		public string Name { get; set; }

		public void Greet(string anotherPerson)
		{
			Console.WriteLine("'Hello, {0}!', {1} said.", anotherPerson, Name);
		}

		// события
		public event Message Came;

		public void OnCame()
		{
			// зачем проверка ?
			if (Came != null)
			{
				Came(Name);
			}
		}

		public Person()
		{
			Task.Factory.StartNew(() => {
				Thread.Sleep(5000);
				OnCame();
			});
		}
	}
}
