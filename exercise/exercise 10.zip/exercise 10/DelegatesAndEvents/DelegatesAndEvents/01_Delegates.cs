﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndEvents
{
	public class Delegates
	{
		public delegate double Function(double x);
		public delegate double Operation(int x);

		public static void Demo(string[] args)
		{
			// метод не является First-class citizen он не существует отдельно от класса
			// так не получится
			//var method = Square;

			Function func = new Function(Square);
			// так тоже можно
			//Function func1 = Square;

			double y = func(6.28);
			Console.WriteLine(y);

			// то же самое
			double x = func.Invoke(6.28);
			Console.WriteLine(x);

			// строгая типизация
			//Function func1 = new Function(Sqrt);

			//Передача подзадачи в задачу.
			int[] arr = {10, 20, 30};

			ProcessArray(arr, Sqrt);

			ProcessArray(arr, Log10);
		}

		static double Square(double x)
		{
			return x * x;
		}

		static double Sqrt(int x)
		{
			return Math.Sqrt(x);
		}

		static double Log10(int x)
		{
			return Math.Log10(x);
		}

		public static void ProcessArray(int[] arr, Operation action)
		{
			foreach (var element in arr)
			{
				Console.WriteLine(action(element));
			}
		}
	}




   
}
