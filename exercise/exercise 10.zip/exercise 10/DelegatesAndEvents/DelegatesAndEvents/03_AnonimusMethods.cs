﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndEvents
{
	public class AnonimusMethods
	{
		public delegate void Handler(int a);

		public static void Demo(string[] args)
		{
			// 3 - Анонимные методы
			Handler anonimus = delegate(int a)
			{
				int b = a + 200;
				Console.WriteLine("Anonimus handler result: " + b);
			};

			anonimus(100);

			// 4 - Лямбда-выражения
			Handler lyambda = (a) =>
			{
				int b = a + 200;
				Console.WriteLine("Lyambda handler result: " + b);
			};

			lyambda(100);

			// стандатные generics
			Action<int, int> action = (a, c) =>
			{
				int b = a + c;
				Console.WriteLine("Action handler result: " + b);
			};

			action(100, 200);

			Func<int, char> function = (a) =>
			{
				int b = a + 100;
				return (char) b;
			};

			Console.WriteLine("function handler result: " + function(57));


			// где используются лямбды
			string[] arr = { "Andromeda", "Aquarius", "Corvus", "Columba", "Serpens", "Cassiopeia", "Pegasus" };

			Func<string, bool> predicate = (element) =>
			{
				return element.StartsWith("C");
			};

			IEnumerable<string> galaxyStartsFromC = arr.FilterCollection(
				element => element.StartsWith("C"));

			//List<string> l = galaxyStartsFromC.ToList<string>();

			// тоже для int

			// LINQ
			IEnumerable<string> galaxyStartsFromClinq =
				arr.Where(element => element.StartsWith("C"));

			Console.Write(String.Join(", ", galaxyStartsFromC));

			Console.Write(String.Join(", ", galaxyStartsFromClinq));

		}

		private static IEnumerable<T> FilterCollection<T>(IEnumerable<T> collection,
			Func<T, bool> predicate)
		{
			foreach (var element in collection)
			{
				if (predicate(element))
					yield return element;
			}
		}
	}

	public static class MyClass
	{
		public static IEnumerable<T> FilterCollection<T>(this IEnumerable<T> collection,
			Func<T, bool> predicate)
		{
			foreach (var element in collection)
			{
				if (predicate(element))
					yield return element;
			}
		}
	}
}
