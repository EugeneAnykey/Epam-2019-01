﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndEvents
{
    class MyClass1
    {
        delegate bool MyComparer(int item);

        private bool EvenNumbers(int item)
        {
            return item % 2 == 0;
        }
        private void Main()
        {
            var arr1 = Filter(array, item => item > 0);
            var arr2 = Filter(array, EvenNumbers);
        }

        private int[] Filter(int[] arr, MyComparer filter)
        {
            var newArr = new List<int>();
            foreach(var item in arr)
            {
                if (filter(item))
                {
                    newArr.Add(item);
                }
            }

            return newArr.ToArray();
        }


        private int[] array = new int[10] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };


    }
}
