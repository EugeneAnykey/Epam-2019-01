﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndEvents
{
	public class MulticastDelegates
	{
		delegate void Message(string name);

		public static void Demo(string[] args)
		{
			Person john = new Person { Name = "John" };
			Person mary = new Person { Name = "Mary" };
			Person hugo = new Person { Name = "Hugo" };

			// экземплярные 
			Message greetByJohn = new Message(john.Greet);
			Message greetByMary = new Message(mary.Greet);
			Message greetByHugo = new Message(hugo.Greet);

			Message greetByUs = (Message)Delegate.Combine(greetByJohn, greetByMary, greetByHugo);
			greetByUs("Bill");

			greetByUs = greetByJohn + greetByMary;
			greetByUs("William");

			greetByUs += greetByHugo;
			greetByUs("Bob");

			greetByUs -= mary.Greet;
			greetByUs("Mike");

			// пустые делегаты
			greetByUs -= greetByJohn;
			greetByUs -= greetByHugo;

			// nothing in there
			greetByUs("George");
		}
	}
}
