﻿using System;
using TriangleArea;

namespace TriangleAreaCalculationTest
{
	class Program
	{
		static void Main()
		{
			CalcArea(3, 4, 5);
			CalcArea(3, 5, 4);
			CalcArea(2, -1, 5);
			CalcArea(2, 2, 5);
			CalcArea(Double.MaxValue, Double.MaxValue, Double.MaxValue);

			Console.ReadKey();
		}

		private static void CalcArea(double a, double b, double c)
		{
			try
			{
				Console.Write("Area for triangle with sides: [{0}] [{1}] [{2}] is ", a, b, c);
				Console.WriteLine(TriangleAreaCalculator.CalcRightTriangleArea(a, b, c));
			}
			catch (ArithmeticException ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
	}
}
