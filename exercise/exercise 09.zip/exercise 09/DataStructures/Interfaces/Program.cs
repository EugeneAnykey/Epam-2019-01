﻿using System;
using System.Collections;
using System.Collections.Generic;


namespace Interfaces
{
	public class Program
	{
		public static void Main(string[] args)
		{
            BaseCollections.Demo(args);
			//DictionaryDemo.ContainsKey();
		}
	}
}
