﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lib
{
	public class Helpers
	{
		public static void WriteArray(int[] arrr)
		{
			//000000
		}
	}
}
