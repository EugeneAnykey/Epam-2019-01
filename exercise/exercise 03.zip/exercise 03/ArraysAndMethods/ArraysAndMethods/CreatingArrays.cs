﻿using System;

namespace ArraysAndMethods
{
	public class CreatingArrays
	{
		public static void Demo(string[] args)
		{
			Console.Write("Введите число элементов массива: ");
			int n = int.Parse(Console.ReadLine());
			int[] arr = new int[n];

			for (int i = 0; i < arr.Length; i++)
			{
				Console.Write("Введите arr[{0}] ", i);
				arr[i] = int.Parse(Console.ReadLine());
			}

			Console.WriteLine("Элементы массива:");

			for (int i = 0; i < n; i++)
			{
				Console.WriteLine("arr[{0}] = {1}", i, arr[i]);
			}

			Console.ReadLine();
		}

		public static void DemoRandom(string[] args)
		{
			int n;
			Console.Write("Введите число элементов массива: ");
			n = int.Parse(Console.ReadLine());
			int[] arr = new int[n];

			Random r = new Random();
			for (int i = 0; i < arr.Length; i++)
			{
				arr[i] = r.Next(100);
			}

			Console.WriteLine("Элементы массива:");

			for (int i = 0; i < n; i++)
			{
				Console.WriteLine("arr[{0}] = {1}", i, arr[i]);
			}

			Console.ReadLine();
		}

		public static void DemoInit(string[] args)
		{
			// -------------------------------------------------------- 
			// Creating and Initializing Arrays.
			// -------------------------------------------------------- 

			// Single-dimensional array.
			int[] singleDimension1 = new int[9];
			int[] singleDimension2 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

			// Mulidimensional array.
			int[,] multiDimensional1 = new int[5, 5];
			int[,] multiDimensional2 = {
				{ 1, 2, 3, 4, 5 },
				{ 6, 7, 8, 9, 10 },
				{ 6, 7, 8, 6, 10 }
			};

			// Jagged array.
			int[][] JaggedArray = new int[10][];
			JaggedArray[0] = new int[5]; // Can specify different sizes
			JaggedArray[1] = new int[7];

			JaggedArray[9] = new int[21];
		}
	}
}
