﻿using System;

namespace ArraysAndMethods
{
	public class NamedAndOptionalParameters
	{
		public static int Diff(int num1, int num2)
		{
			return num1 - num2;
		}

		public static int Sum(int num1, int num2, int num3 = 0,
			int num4 = 0)
		{
			return num1 + num2 + num3 + num4;
		}

		public static void DrawRectangle(int x, int y, bool isFilled = false)
		{
			// drawing rectangle
			Console.WriteLine(isFilled ? "filled" : "not filled");
		}

		public static void Demo(string[] args)
		{
			Console.WriteLine(Diff(num1: 5, num2: 2));
			Console.WriteLine(Diff(num2: 2, num1: 5));
			
			Console.WriteLine(Sum(1, 2, 3, 4));
			Console.WriteLine(Sum(1, 2));
			Console.WriteLine(Sum(1, 2, 3));
			Console.WriteLine(Sum(1, 2, num4: 3));

			DrawRectangle(10, 10, true);
			DrawRectangle(10, 10, isFilled: true);
			DrawRectangle(isFilled: false, x: 10, y: 10);
			DrawRectangle(10, 10);

			Console.ReadKey();
		}
	}
}
