﻿namespace ArraysAndMethods
{
	class Program
	{
		static void Main(string[] args)
		{
			//CreatingArrays.Demo(null);
			ArrayMethods.Demo(null);
		}
	}
}
