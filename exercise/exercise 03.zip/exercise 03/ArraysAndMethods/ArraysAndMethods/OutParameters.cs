﻿using System;

namespace ArraysAndMethods
{
	public class OutParameters
	{
		static void Funct(out int n)
		{
			n = int.Parse(Console.ReadLine());
			// out parameters should be initialized in this method
			Console.WriteLine(n);
		}

		public static void Demo(string[] args)
		{
			int x;
			Funct(out x);

			Console.WriteLine(x);
			Console.Read();
		}

		// полезный пример логики TryDoSomething
		public static void DemoTryParse(string[] args)
		{
			string param = Console.ReadLine();

			int paramValue;
			int.TryParse(param, out paramValue);

			if (int.TryParse(param, out paramValue))
			{
				paramValue++;
				Console.WriteLine(paramValue);
			}

			Console.Read();
		}
	}
}
