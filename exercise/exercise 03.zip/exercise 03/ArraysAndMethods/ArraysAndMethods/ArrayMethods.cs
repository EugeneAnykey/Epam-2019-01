﻿using System;

namespace ArraysAndMethods
{
	public class ArrayMethods
	{
		public static void Demo(string[] args)
		{
			// -------------------------------------------------------- 
			// Common Properties and Methods Exposed by Arrays.
			// -------------------------------------------------------- 

			int[] arr = { 1, -2, 3, 4, -5, 2, 7, 1, 9 };

			// Length example.
			int numbersLength = arr.Length;
			long numbersLongLength = arr.LongLength;
			// Returns the value 9


			// GetLength example.
			int count = arr.GetLength(0);

			int[,] multiDimensional2 = {
				{ 1, 2, 3, 4, 5 },
				{ 6, 7, 8, 9, 10 },
				{ 6, 7, 8, 6, 10 }
			};

			// Rank example.
			int rank = arr.Rank;
			// Returns the value 1

			int res1 = Array.IndexOf(arr, 1);
			// 0
			int res11 = Array.IndexOf(arr, 99);
			// -1
			int res2 = Array.LastIndexOf(arr, 1);
			// 7
			Array.Sort(arr);
			// void

			// CopyTo example.
			int[] newArr = new int[arr.Length];
			Array.Copy(arr, newArr, 0);
		}
	}
}
