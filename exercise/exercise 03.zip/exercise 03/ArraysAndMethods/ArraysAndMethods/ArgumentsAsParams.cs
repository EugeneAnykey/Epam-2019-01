﻿using System;

namespace ArraysAndMethods
{
	public class ArgumentsAsParams
	{
		static int Max(params int[] par)
		{
			// для корректной работы метода необходимо проверять переданные на вход аргументы
			if (par.Length == 0)
			{
				throw new ArgumentException("В метод не передано ни одного значения");
			}

			int max = par[0];

			for (int i = 1; i < par.Length; i++)
			{
				if (max < par[i])
				{
					max = par[i];
				}
			}

			return max;
		}

		public static void Demo(string[] args)
		{
			int max = Max(3, 7, 4);

			try
			{
				Max();
			}
			catch (ArgumentException ex)
			{
				Console.WriteLine(ex.Message);
			}

			Console.Read();
		}
	}
}
