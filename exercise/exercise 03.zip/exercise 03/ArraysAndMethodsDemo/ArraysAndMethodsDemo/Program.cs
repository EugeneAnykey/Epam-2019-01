﻿using System;

namespace ArraysAndMethodsDemo
{
	class Program
	{
		// https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/arrays/
		// https://docs.microsoft.com/en-us/dotnet/api/system.array?view=netframework-4.7.2
		static void Main(string[] args)
		{
			Examples.OneDimentionalArrayUsage();
			Examples.ReadArrayFromKeyboardInput();
			Examples.OtherArrays();
			Examples.ArrayClass();
		}
	}

	public class Examples
	{
		// в методе остутсвуют проверки значения и предполагается,
		// что пользователь будет вводить только числа
		public static void ReadArrayFromKeyboardInput()
		{
			Console.WriteLine("Введите число элементов массива:");
			var length = int.Parse(Console.ReadLine());
			var array = new int[length];
			for (int i = 0; i < array.Length; i++)
			{
				Console.WriteLine($"Введите значение элемента под номером {i + 1}:");
				array[i] = int.Parse(Console.ReadLine());
			}

			var arrayElements = string.Join(",", array);
			Console.WriteLine($"Вы создали и заполнили следующий массив: {arrayElements}");
		}

		public static void OneDimentionalArrayUsage()
		{
			// объявление переменной массива
			long[] array;

			// инициализация переменной
			array = new long[8];

			// другой способ, когда значения массива известны на момент объявления
			// компилятор сам поймёт тип 
			var otherArray = new[] { 1, 3, 4, 5 };
			// или нужно ему подсказать, когда это не однозначно понятно
			var oneMoreArray = new object[] { 1, 3, "четыре" };

			// доступ к элементам массива осуществляется через индекс
			array[0] = 5;
			array[1] = 7;
			// array[2] = "три"; - все элементы массива должны быть одного типа.
			// но т.к. int неявно можно привести к long, то следующее допустимо
			int a = 3;
			array[2] = a;

			// обращение по индексу возвращает значение того типа, которое было записано
			// поэтому можно сразу можно использовать это значение в различных операциях
			array[2] = array[1] + 1;
			// или передавать в методы
			Console.WriteLine($"Значение второго элемента массива: {array[1]}");
			// неинициализированные элементы массива - значения по умолчанию
			Console.WriteLine($"Значение ранее неинициализированного элемента массива: {array[5]}");
		}

		public static void OtherArrays()
		{
			// рваный массив (массив массивов)
			var jaggedArray = new int[3][];
			// результат:
			//  null
			//  null
			//  null

			jaggedArray[0] = new int[4];
			jaggedArray[1] = new int[2];
			jaggedArray[2] = new int[8];
			// результат:
			//  0  0  0  0
			//  0  0
			//  0  0  0  0  0  0  0  0

			jaggedArray[0][2] = 4;
			jaggedArray[2][1] = 94;
			jaggedArray[1][0] = -2;
			// результат:
			//  0  0  4  0
			//  0 94
			// -2  0  0  0  0  0  0  0

			//многомерный массив
			var mdArray = new int[3, 5];
			mdArray[0, 0] = 5;
			mdArray[0, 1] = -1;
			mdArray[0, 2] = 94;
			mdArray[1, 3] = 80;
			mdArray[2, 2] = -2;
			// результат:
			//  5 -1 94  0  0  0
			//  0  0  0 80  0  0
			//  0  0 -2  0  0  0
		}

		public static void ArrayClass()
		{
			var array = new[] { 1, 2, 3, -2, 0, -1, 3 };

			Array.Sort(array);
			Array.IndexOf(array, 5);
			Array.Clear(array, 0, array.Length);
			
			var newArray = new long[4];
			Array.Copy(array, newArray, 4);
			Array.Reverse(array);
			var firstPositiveElement = Array.Find(array, a => a > 0);
			var allNegativeElements = Array.FindAll(array, a => a < 0);
		}
	}
}
