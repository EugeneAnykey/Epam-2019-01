﻿using System;

namespace MethodsDemo
{
	class Program
	{
		static void Main(string[] args)
		{
			Examples.StaticNonStatic();
			Examples.DefaultParameters();
			Examples.NamedParameters();
			Examples.Params();
			Examples.RefParameter();
			Examples.OutParameters();
		}
	}

	class Examples
	{
		public static void StaticNonStatic()
		{
			var user1 = new User("Вася");
			PrintNewUserMessage(user1.Name);
			var user2 = new User("Петя");
			PrintNewUserMessage(user2.Name);
			// для статических методов и переменных не нужно создавать объект.
			// они могут быть прочитаны и изменены любым экземпляром класса,
			// но при этом значение будет _общим_, в отличие от не статических членов
			// (например, Name меняется для каждого экземпляра по-отдельности).
			Console.WriteLine($"Пользователей создано: {User.Count}");
		}

		private static void PrintNewUserMessage(string name)
		{
			Console.WriteLine($"Создан пользователь с именем {name}");
		}

		public static void NamedParameters()
		{
			// вызов метода с передачей аргументов по имени
			var result = Examples.SomeMathOperation(12, op3: 6);
		}

		public static void DefaultParameters()
		{
			// значения по умолчанию будут использованы вместо для тех переменных, что не были переданы
			var result = Examples.SomeMathOperation(2, 1);
		}

		private static int SomeMathOperation(int op1 = 0, int op2 = 0, int op3 = 1)
		{
			return op1 + op2 / op3;
		}

		public static void Params()
		{
			// то же самое, что и SumExample(new int[]{ 1, 20, -12, 1 })
			var result = Examples.Sum(1, 20, -12, 1);
		}

		private static int Sum(params int[] numbers)
		{
			var sum = 0;
			foreach (var number in numbers)
			{
				sum += number;
			}

			return sum;
		}

		public static void RefParameter()
		{
			var a = 1;
			var b = 2;
			Console.WriteLine("Переменные до передачи в метод:");
			ShowVariable(nameof(a), a);
			ShowVariable(nameof(b), b);

			ValueTypesAndRefParameters(a, ref b);

			Console.WriteLine("После выполнения метода:");
			ShowVariable(nameof(a), a);
			ShowVariable(nameof(b), b);

			var user1 = new User("Лена");
			var user2 = new User("Оля");

			Console.WriteLine("Переменные до передачи в метод:");
			ShowVariable(nameof(user1), user1.Name);
			ShowVariable(nameof(user2), user2.Name);

			ReferenceTypesAndRefParameters(user1, ref user2);

			Console.WriteLine("После выполнения метода:");
			ShowVariable(nameof(user1), user1.Name);
			ShowVariable(nameof(user2), user2?.Name ?? "null");
		}

		// Значение переменной copy со стека будет скопировано, в то время как 
		// originalVariable будет не копией, а именно той переменной, что и была передана
		private static void ValueTypesAndRefParameters(int copy, ref int originalVariable)
		{
			copy = 3;
			originalVariable = 4;
		}

		// Значение переменной copy со стека будет скопировано, в то время как 
		// originalVariable будет не копией, а именно той переменной, что и была передана
		private static void ReferenceTypesAndRefParameters(User copy, ref User originalVariable)
		{
			// обращаемся через _копию_ ссылки к значению в куче и меняем его
			// теперь _все_, кто ссылается на этот объект, будут возвращать измененное значение
			copy.Name = "Елена";
			// присваиваем копии ссылки значение null, оригинал всё ещё ссылается на объект
			copy = null;

			// то же самое, что и с copy, но уже работаем с той же ссылкой, что была передана, 
			// не с копией
			originalVariable.Name = "Ольга";
			// присваиваем оригинальной ссылке значение null
			originalVariable = null;
		}

		private static void ShowVariable(string name, int value)
		{
			Console.WriteLine($"{name}: {value}");
		}

		private static void ShowVariable(string name, string value)
		{
			Console.WriteLine($"{name}: {value}");
		}

		public static void OutParameters()
		{
			// out используется для того, чтобы возвращать из методов больше одного значения
			// например, когда одновременно нужно проверить возможность возвращения значения
			// и вернуть его
			int parsedValue;
			int.TryParse("21", out parsedValue);

			int elem;
			// почему?
			var examples = new Examples();
			examples.TryFindFirstPositiveElement(out elem, -1, -23, 0, -120, 2);
		}

		private bool TryFindFirstPositiveElement(out int positiveElement, params int[] numbers)
		{
			foreach (var number in numbers)
			{
				if (number > 0)
				{
					positiveElement = number;
					// выходить из метода можно в любом месте, но
					// всегда после того, как проинициализированы все out аргументы
					return true;
				}
			}

			positiveElement = default(int);
			return false;
		}
	}

	class User
	{
		public static int Count { get; private set; }
		public string Name;

		public User(string name)
		{
			Name = name;
			Count++;
		}
	}
}
