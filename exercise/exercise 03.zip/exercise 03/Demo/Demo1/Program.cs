﻿using MathFunctions;
using System;
using System.Linq;

namespace Demo1
{
	class MyClass
	{
		public void DoSomeWork()
		{

		}
	}

	class Program
	{
		private string name1;

		static void Main(string[] args)
		{
			Calc.Sum();
			var processor = new MyClass();
			processor.DoSomeWork();
			int age = 10;
			string name = "Andrey";
			var str = $"User {name} {age}";
			var str1 = string.Format("User {0} {1}", name, age);

			var rnd1 = new Random();
			// var rnd2 = new Random();
			var num1 = rnd1.Next(0, 1000);
			var num2 = rnd1.Next(0, 1000);
			// num = rnd.Next(0, 100);
			// Console.WriteLine(num);

			var arr = new int[5] { 1, 2, 3, 4, 5 };
			foreach (var i in arr)
			{
				Console.WriteLine(i);
			}

			Array.Clear(arr, 0, 3);
			Method1();
			Method1(
				name: "fsdfsd",
				isAlive: false);

			int number = 1;
			var result = TryParseToInt34("asdasd", number);
			result = TryParseToInt33("asdasd", ref number);





			Sum(0);
			Sum(1, 2, 3, 4, 5);

			int? nullableInt = null;
			// nullableInt.HasValue;

			int nonNullableInt = nullableInt.HasValue ? nullableInt.Value + age : 0;
			Console.ReadKey();
		}

		static void Method1(string name = "", int age = 0, bool isAlive = true, byte sex = 1)
		{

		}

		static bool TryParseToInt32(string input, out int num)
		{
			// logic
			bool isNumber = true;
			num = isNumber ? int.Parse(input) : default(int);
			return isNumber;
		}

		static bool TryParseToInt34(string input, int num)
		{
			num = 10;
			return true;
		}

		static bool TryParseToInt33(string input, ref int num)
		{
			num = 10;
			return true;
		}

		static int Sum(params int[] args)
		{
			return args.Sum();
		}
	}
}
