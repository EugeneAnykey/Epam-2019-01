﻿namespace MathFunctions
{
	public static class Calc
	{
		public static int Sum()
		{
			return 0;
		}
	}
}
