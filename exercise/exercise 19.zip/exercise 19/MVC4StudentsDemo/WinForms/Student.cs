﻿namespace WinForms
{
	// TODO реализовать проверку ограничений
	public class Student
	{
		public string FullName { get; set; }
		public int Year { get; set; }
		public int PassNumber { get; set; }
	}
}
