﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NetBasicsDemo
{
	class _00_ShowIllDasm
	{
		// on math lib
		// C:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\Bin
	}
}
