﻿using System;
using System.Runtime;

namespace NetBasicsDemo
{
	class Program
	{
		static void Main(string[] args)
		{
			//HashCodeDemo.Demo(args);

			var result = MathLibrary.Functions.Factorial(5);
			Console.WriteLine(result);

			// включаем задержку сборки второго поколения и смотрим как цикл отжирает память
			/*GCSettings.LatencyMode = GCLatencyMode.LowLatency;
			var str = "";
			for (var i = 0; i < 50000; i++)
			{
				str += " Some string ";
			}*/
		}
	}
}
