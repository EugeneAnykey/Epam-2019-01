
USE [UsersAndRewards]
GO

CREATE PROCEDURE [dbo].[GetUserRewards](@userId int)
AS

SELECT Rewards.RewardId, Title, [Description]
	FROM Rewards INNER JOIN UserRewards ON Rewards.RewardId = UserRewards.RewardId
		WHERE UserId = @userId


GO

CREATE PROCEDURE [dbo].[GetUsers]
As
	SELECT UserId, [FirstName], [LastName], [Birthdate]
		FROM [User]


GO

CREATE PROCEDURE [dbo].[InsertUser](
	@firstName nvarchar(100),
	@lastName nvarchar(100),
	@birthdate datetime)
As
	INSERT INTO [User](FirstName, LastName, Birthdate)
		OUTPUT INSERTED.UserId
			VALUES(@firstName, @lastName, @birthdate)

GO

CREATE TYPE dbo.Rewards AS TABLE
(
  RewardId INT
);
GO

CREATE PROCEDURE [dbo].[InsertUserRewards](
	@userId int,
	@rewardIds AS dbo.Rewards READONLY)
As
	INSERT INTO UserRewards(UserId, RewardId)
		SELECT @userId, RewardId FROM @rewardIds

GO