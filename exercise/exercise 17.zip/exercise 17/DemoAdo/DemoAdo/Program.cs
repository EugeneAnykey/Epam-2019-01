﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DemoAdo
{
    class Program
    {
        static void Main(string[] args)
        {
            var connectionString = ConfigurationManager
                .ConnectionStrings["MyConnectionString"].ConnectionString;
            
            DisplayUsers(connectionString);

            var newUser = new User
            {
                Id = 0,
                Name = "new user name2",
                Birthdate = DateTime.Now,
                Awards = new List<Award>
                {
                    new Award
                    {
                        Id = 1,
                        Name = "nobel prize",
                        Descriptions = "epic award"
                    }
                }
            };
            AddUser(newUser, connectionString);
            DisplayUsers(connectionString);
        }

        public static List<User> GetAllUsers(string connectionString)
        {
            var users = new List<User>();
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("SELECT * FROM USERS");
                command.Connection = connection;
                connection.Open();
                var reader = command.ExecuteReader();
                if (!reader.HasRows)
                {
                    return users;
                }

                while(reader.Read())
                {
                    var id = reader.GetInt32(0);
                    var name = (string)reader["Name"];
                    var birthdate = reader.GetDateTime(2);

                    var user = new User
                    {
                        Id = id,
                        Name = name,
                        Birthdate = birthdate
                    };
                    users.Add(user);
                }
            }
            //var connection = new SqlConnection(connectionString);
            //try
            //{
            //    connection.Open();
            //      logic
            //}
            //catch (Exception ex)
            //{

            //}
            //finally
            //{
            //    connection.Close();
            //}

            return users;
        }

        public static void AddUser(User user, string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                // var command = new SqlCommand($"INSERT INTO Users VALUES({txtId.Text}, {user.Name}, {user.Birthdate})");
                // var command = new SqlCommand("INSERT INTO Users(Name, Birthdate) VALUES(@name, @birthdate)");
                var command = new SqlCommand("AddUser");
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = connection;
                command.Parameters.AddWithValue("@name", user.Name);
                command.Parameters.AddWithValue("@bdate", user.Birthdate);

                // adding user rewards
                DataTable rewardsTable = new DataTable();
                rewardsTable.Columns.Add(new DataColumn("id", typeof(int)));
                foreach (var award in user.Awards)
                {
                    rewardsTable.Rows.Add(award.Id);
                }

                SqlParameter awardParameter = command.Parameters.AddWithValue("@awardIds", rewardsTable);
                awardParameter.SqlDbType = SqlDbType.Structured;

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public static void RemoveUser(int id)
        {

        }

        public static void DisplayUsers(string connectionString)
        {
            Console.WriteLine();
            var users = GetAllUsers(connectionString);
            foreach (var user in users)
            {
                Console.WriteLine($"Id: {user.Id}, Name: {user.Name}, Birthdate: {user.Birthdate}");
            }
        }
    }
}
