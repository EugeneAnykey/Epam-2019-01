﻿namespace DemoAdo
{
    public class Award
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Descriptions { get; set; }
    }
}
