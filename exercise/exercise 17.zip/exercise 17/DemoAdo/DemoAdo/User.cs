﻿using System;
using System.Collections.Generic;

namespace DemoAdo
{
    public class User
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public DateTime Birthdate { get; set; }

        public List<Award> Awards { get; set; }
    }
}
