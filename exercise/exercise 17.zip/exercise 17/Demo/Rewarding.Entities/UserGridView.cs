﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Rewarding.Entities
{
	public class UserGridView
	{
		public int Id { get; set; }

		public string FirstName { get; set; }

		public string LastName { get; set; }

		public DateTime Birthdate { get; set; }

		public int Age { get; set; }

		public string Rewards { get; set; }

		public static UserGridView GetModel(User user)
		{
			return new UserGridView
			{
				Id = user.Id,
				FirstName = user.FirstName,
				LastName = user.LastName,
				Birthdate = user.Birthdate,
				Age = user.Age,
				Rewards = string.Join(", ", user.Rewards?.Select(r => r.Title) ?? new List<string>())
			};
		}
	}
}
