﻿using Rewarding.DAL.DataService;
using Rewarding.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Rewarding.WinForms
{
	public partial class MainForm : Form
	{
		private DataService service;

		public MainForm(DataService service)
		{
			InitializeComponent();
			// ctlUsers.AutoGenerateColumns = false;
			this.service = service;
			DisplayUsers();
		}

		private void MainForm_Click(object sender, EventArgs e)
		{

		}

		private void MainForm_ResizeBegin(object sender, EventArgs e)
		{

		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnAddUser_Click(object sender, EventArgs e)
		{
			AddUser();
		}

		private void btnContextMenuAdd_Click(object sender, EventArgs e)
		{
			AddUser();
		}

		private void AddUser()
		{
			var user = new User();
			user.FirstName = "Third User";
			user.LastName = "Third Userovich";
			user.Birthdate = DateTime.Now;
			user.Rewards = new List<Reward>
			{
				new Reward { Id = 3, Title = "title3", Description = "description3" }
			};

			service.AddUser(user);
			DisplayUsers();
		}

		private void DisplayUsers()
		{
			var users = service.GetUsers().ToList();
			//var usersView = new List<UserGridView>();
			//for (var i = 0; i < users.Count; i++)
			//{
			//	var uv = UserGridView.GetModel(users[i]);
			//	usersView.Add(uv);
			//}

			//var usersView = users.Select(u =>
			//{
			//	return UserGridView.GetModel(u);
			//});

			//var usersView = users.Select(u => UserGridView.GetModel(u));

			var usersView = users.Select(UserGridView.GetModel).ToList();

			ctlUsers.DataSource = usersView;
		}
	}
}
