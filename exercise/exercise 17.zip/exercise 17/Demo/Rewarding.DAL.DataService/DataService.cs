﻿using Rewarding.Entities;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Rewarding.DAL.DataService
{
	public class DataService
	{
		private readonly string connectionString;
		public DataService(string connectionString)
		{
			this.connectionString = connectionString;
		}

		public User AddUser(User user)
		{
			using (var connection = new SqlConnection(connectionString))
			using(var command = new SqlCommand())
			{
				command.CommandText = "InsertUser";
				command.CommandType = CommandType.StoredProcedure;
				command.Connection = connection;

				command.Parameters.AddWithValue("@firstName", user.FirstName);
				command.Parameters.AddWithValue("@lastName", user.LastName);
				command.Parameters.AddWithValue("@birthdate", user.Birthdate);

				connection.Open();

				var result = command.ExecuteScalar();
				var userId = (int)result;
				user.Id = userId;

				AddUserRewards(connection, user);

				connection.Close();
			}

			return user;
		}

		private void AddUserRewards(SqlConnection connection, User user)
		{
			DataTable tempRewardsTable = new DataTable();
			tempRewardsTable.Columns.Add("RewardId", typeof(int));
			foreach (var r in user.Rewards)
			{
				tempRewardsTable.Rows.Add(r.Id);
			}

			using (var command = new SqlCommand())
			{
				command.CommandText = "InsertUserRewards";
				command.CommandType = CommandType.StoredProcedure;
				command.Connection = connection;


				command.Parameters.AddWithValue("@userId", user.Id);
				var rewardsTablePArameter = command.Parameters.AddWithValue("@rewardIds", tempRewardsTable);
				rewardsTablePArameter.SqlDbType = SqlDbType.Structured;

				command.ExecuteNonQuery();
			}
		}

		public ICollection<User> GetUsers()
		{
			var users = new List<User>();
			using (var connection = new SqlConnection(connectionString))
			using (var command = new SqlCommand())
			{
				command.CommandText = "GetUsers";
				command.CommandType = CommandType.StoredProcedure;
				command.Connection = connection;

				connection.Open();

				var reader = command.ExecuteReader();
				if (reader.HasRows)
				{
					while (reader.Read())
					{
						var user = new User();
						user.Id = reader.GetInt32(0);
						user.FirstName = reader.GetString(1);
						user.LastName = reader.GetString(2);
						user.Birthdate = reader.GetDateTime(3);
						users.Add(user);
					}
				}

				connection.Close();
			}
			FillUserRewards(users);
			return users;
		}

		private void FillUserRewards(List<User> users)
		{
			foreach(var user in users)
			{
				user.Rewards = new List<Reward>();
				using (var connection = new SqlConnection(connectionString))
				using (var command = new SqlCommand())
				{
					command.CommandText = "GetUserRewards";
					command.CommandType = CommandType.StoredProcedure;
					command.Connection = connection;
					command.Parameters.AddWithValue("@userId", user.Id);

					connection.Open();

					var reader = command.ExecuteReader();
					if (reader.HasRows)
					{
						while (reader.Read())
						{
							var reward = new Reward();
							reward.Id = reader.GetInt32(0);
							reward.Title = reader.GetString(1);
							reward.Description = reader.GetString(2);
							user.Rewards.Add(reward);
						}
					}

					connection.Close();
				}
			}
		}
	}
}
