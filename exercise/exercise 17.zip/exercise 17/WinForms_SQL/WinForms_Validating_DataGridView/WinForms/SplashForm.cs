﻿using System.Windows.Forms;

namespace WinForms
{
	public partial class SplashForm : Form
	{
		public SplashForm()
		{
			InitializeComponent();
		}
	}
}
